package com.examples;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

import android.os.Bundle;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.support.v4.app.NavUtils;

public class Writer extends Activity implements OnClickListener{
	public String date_month_year;
	public String entry;
//	private Button sv;
	private EditText Text;
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	Intent intent=getIntent();
    	date_month_year = intent.getStringExtra(DisplayMenu.date);
    	entry = intent.getStringExtra(DisplayMenu.text);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_writer);
       // setTitle("Edit Journal of "+date_month_year);
        setTitle("Daily Journal                                 "+date_month_year);
        Text = (EditText) findViewById(R.id.etText);
        Text.setText(entry,TextView.BufferType.EDITABLE);
        Text.setSelection(Text.getText().length());
	//	sv = (Button) findViewById(R.id.bSave);
		//sv.setOnClickListener(this);
    //    getActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_writer, menu);
        return true;
    }
    @Override
    public void onBackPressed()
    {
    	String name = Text.getText().toString();
		/*Database newdb = new Database(Writer.this);
		newdb.open();
		newdb.updateText(date_month_year,name);
		newdb.close();*/
    	File myFile = new File("/sdcard/journal/"+date_month_year+".txt");
		try {
			myFile.createNewFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		FileOutputStream fOut = null;
		try {
			fOut = new FileOutputStream(myFile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		OutputStreamWriter myOutWriter = new OutputStreamWriter(fOut);
		try {
			myOutWriter.write(name);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			myOutWriter.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			fOut.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		finish();
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                NavUtils.navigateUpFromSameTask(this);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
    public void onClick(View v) {

    //	if(v==sv)
    	//{
    //		String name = Text.getText().toString();
		//	Database newdb = new Database(Writer.this);
		//	newdb.open();
			//newdb.updateText(date_month_year,name);
		//	newdb.close();
			//finish();
    	//}
	/*	switch (arg0.getId()) {
		case R.id.bSave:
			try {
				String name = Text.getText().toString();
			//	String name = date_month_year;
				//String hotness = text.getText().toString();
				Database newdb = new Database(Writer.this);
				newdb.open();
				newdb.updateText(date_month_year,name);
				newdb.close();
			} catch (Exception e) {

			} finally {
				//Dialog d = new Dialog(this);
			//	d.setTitle("HEack YUP");
				//TextView tv = new TextView(this);
			//	tv.setText("Text");
				//d.setContentView(tv);
			//	d.show();
			}
			
		}*/

	}

}
/*<Button
android:id="@+id/bSave"
android:layout_width="wrap_content"
android:layout_height="wrap_content"
android:text="Back" >
</Button>*/
