package com.examples;

import java.io.File;
import java.util.Date;
import java.text.SimpleDateFormat;

import android.net.ParseException;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.GridView;
import android.widget.ImageButton;
import android.support.v4.app.NavUtils;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.Toast;
import android.view.ViewGroup;

@TargetApi(5)
public class Photos extends Activity implements OnClickListener {

	private static final int ACTION_TAKE_IMAGE = 200;
	private ImageButton makephoto;
	public String date_month_year;
	private final static Uri MEDIA_EXTERNAL_CONTENT_URI = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
	private final static String _ID = MediaStore.Images.Media._ID;
	private final static String MEDIA_DATA = MediaStore.Images.Media.DATA;
	private GridView _gallery;
	private Cursor _cursor;
	private int _columnIndex;
	private int[] _imagesId;
	private Uri _contentUri;
	protected Context _context;
	public String epchTime;
	public Date selecteddate;
	public Bundle Instance;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Intent intent = getIntent();

		date_month_year = intent
				.getStringExtra(SimpleCalendarViewActivity.GridCellAdapter.DateSelected);
		// epchTime =
		// intent.getStringExtra(SimpleCalendarViewActivity.GridCellAdapter.epochetime);
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
		selecteddate = null;
		try {
			selecteddate = (Date) formatter.parse(date_month_year);
		} catch (java.text.ParseException e) {

			e.printStackTrace();
		}

		// Toast.makeText(getApplicationContext(), epchTime,
		// Toast.LENGTH_LONG).show();
		_context = getApplicationContext();
		setContentView(R.layout.activity_photos);
		_gallery = (GridView) this.findViewById(R.id.photosGrdVw);
		makephoto = (ImageButton) this.findViewById(R.id.makethephoto);
		makephoto.setOnClickListener(this);
		_contentUri = MEDIA_EXTERNAL_CONTENT_URI;
		initImagesId();
		setGalleryAdapter();

		// System.out.print(epchTime);
		// getActionBar().setDisplayHomeAsUpEnabled(true);
	}

	@Override
	public void onResume() {
		// super.onResume();
		super.onRestart();
		initImagesId();
		setGalleryAdapter();
	}

	private void setGalleryAdapter() {
		_gallery.setAdapter(new ImageGalleryAdapter(_context));
		_gallery.setOnItemClickListener(_itemClickLis);
	}

	private AdapterView.OnItemClickListener _itemClickLis = new OnItemClickListener() {
		public void onItemClick(AdapterView parent, View v, int position,
				long id) {
			// Now we want to actually get the data location of the file
			String selection = MediaStore.Images.Media.DATE_TAKEN + ">="
					+ Long.toString(selecteddate.getTime()) + " AND "
					+ MediaStore.Images.Media.DATE_TAKEN + "<"
					+ Long.toString(selecteddate.getTime() + 86400000);
			String[] proj = { MediaStore.Images.Media._ID,
					MediaStore.Images.Media.DATA,
					MediaStore.Images.Media.TITLE,
					MediaStore.Images.Media.MIME_TYPE,
					MediaStore.Images.Media.DATE_TAKEN };
			// We request our cursor again
			@SuppressWarnings("deprecation")
			Cursor cursor = getContentResolver().query(
					MediaStore.Images.Media.EXTERNAL_CONTENT_URI, proj, // Which
																		// columns
																		// to
																		// return
					selection, // WHERE clause; which rows to return (all rows)
					null, // WHERE clause selection arguments (none)
					null); // Order-by clause (ascending by name)
			// We want to get the column index for the data uri
			int count = cursor.getCount();

			cursor.moveToFirst();
			cursor.moveToPosition(position);
			int columnIndex = cursor
					.getColumnIndex(MediaStore.Images.Media.DATA);
			int mimeColumn = cursor
					.getColumnIndex(MediaStore.Images.Media.MIME_TYPE);

			int datecolumn = cursor
					.getColumnIndex(MediaStore.Images.Media.DATE_TAKEN);

			String mimeType = cursor.getString(mimeColumn);
			String filename = cursor.getString(columnIndex);
			String DateAdded = cursor.getString(datecolumn);

			Intent intent = new Intent(android.content.Intent.ACTION_VIEW);
			File newFile = new File(filename);
			intent.setDataAndType(Uri.fromFile(newFile), mimeType);
			startActivity(intent);
			showToast(DateAdded);
		}
	};

	@SuppressWarnings("deprecation")
	private void initImagesId() {
		try {
			String[] proj = { _ID };
			String selection = MediaStore.Images.Media.DATE_TAKEN + ">="
					+ Long.toString(selecteddate.getTime()) + " AND "
					+ MediaStore.Images.Media.DATE_TAKEN + "<"
					+ Long.toString(selecteddate.getTime() + 86400000);
			_cursor =getContentResolver().query(_contentUri, proj, // Which columns to return
					selection, // WHERE clause; which rows to return (all rows)
					null, // WHERE clause selection arguments (none)
					null); // Order-by clause (ascending by name)
			int count = _cursor.getCount();
			// We now get the column index of the thumbnail id
			_columnIndex = _cursor.getColumnIndex(_ID);
			// initialize
			_imagesId = new int[count];
			// move position to first element
			_cursor.moveToFirst();
			for (int i = 0; i < count; i++) {
				int id = _cursor.getInt(_columnIndex);
				//
				_imagesId[i] = id;
				//
				_cursor.moveToNext();
				//
			}
		} catch (Exception ex) {
			showToast(ex.getMessage().toString());
		}

	}

	protected void showToast(String msg) {
		Toast.makeText(_context, msg, Toast.LENGTH_LONG).show();
	}

	private class ImageGalleryAdapter extends BaseAdapter {
		public ImageGalleryAdapter(Context c) {
			_context = c;
		}

		public int getCount() {
			return _imagesId.length;
		}

		public Object getItem(int position) {
			return position;
		}

		public long getItemId(int position) {
			return position;
		}

		public View getView(int position, View convertView, ViewGroup parent) {
			ImageView imgVw = new ImageView(_context);
			;
			try {
				if (convertView != null) {
					imgVw = (ImageView) convertView;
				}
				imgVw.setImageBitmap(getImage(_imagesId[position]));
				imgVw.setLayoutParams(new GridView.LayoutParams(96, 96));
				imgVw.setPadding(8, 8, 8, 8);
			} catch (Exception ex) {
				System.out.println("StartActivity:getView()-135: ex "
						+ ex.getClass() + ", " + ex.getMessage());
			}
			return imgVw;
		}

		// Create the thumbnail on the fly
		private Bitmap getImage(int id) {
			Bitmap thumb = MediaStore.Images.Thumbnails.getThumbnail(
					getContentResolver(), id,
					MediaStore.Images.Thumbnails.MICRO_KIND, null);
			// Bitmap bmp2 =
			// BitmapFactory.decodeResource(getResources(),R.drawable.cal_right_arrow_on);
			// Bitmap bmOverlay =
			// Bitmap.createBitmap(thumb.getWidth(),thumb.getHeight(),thumb.getConfig());
			// Canvas canvas= new Canvas(bmOverlay);
			// canvas.scale((float) 1.0, (float) 1.0);
			// canvas.drawBitmap(thumb, new Matrix(), null);
			// canvas.drawBitmap(bmp2, 20 ,20, null);
			// canvas.save();
			return thumb;
		}

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.activity_photos, menu); // some
																	// correction
																	// here
																	// /......
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			NavUtils.navigateUpFromSameTask(this);
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	private void dispatchTakePhotoIntent() {
		// Intent takeVideoIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
		// Intent takePhotoIntent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		Intent takePhotoIntent = new Intent(
				MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA);
		// takePhotoIntent.putExtra(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA,1);
		startActivityForResult(takePhotoIntent, ACTION_TAKE_IMAGE);
	}

	public void onClick(View v) {
		if (v == makephoto) {
			dispatchTakePhotoIntent();

		}

	}

}
