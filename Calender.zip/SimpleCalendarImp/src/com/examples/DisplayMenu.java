package com.examples;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import android.R.integer;
import android.net.ParseException;
import android.os.Bundle;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.support.v4.app.NavUtils;

@TargetApi(9)
public class DisplayMenu extends Activity implements OnClickListener{

	private ImageButton journalid;
	private ImageButton photoid;
	private ImageButton videoid;
	public String date_month_year;
	public String read;
	public static String date="00-00-0000";
	public static String text="";
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        date_month_year = intent.getStringExtra(SimpleCalendarViewActivity.GridCellAdapter.DateSelected);
        read=intent.getStringExtra(SimpleCalendarViewActivity.GridCellAdapter.CanRead);
        setContentView(R.layout.activity_display_menu);
        journalid = (ImageButton) this.findViewById(R.id.journalid);
        journalid.setOnClickListener(this);
        photoid = (ImageButton) this.findViewById(R.id.photoid);
        photoid.setOnClickListener(this);
        videoid = (ImageButton) this.findViewById(R.id.videoid);
        videoid.setOnClickListener(this);
        setTitle("Menu                                             "+date_month_year);
        //   getActionBar().setDisplayHomeAsUpEnabled(true);
        Date today=new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("d-MMMMM-yyyy");
      /*  Date Last_date= null;
                Date Future_date= null;
                Database db= new Database(DisplayMenu.this);
                db.open();
                db.createEntry("2-November-2012", "30-November-2012");
                Cursor c=db.getdata();
                c.moveToFirst();
                try {

                        Last_date = (Date) formatter.parse(c.getString(1));
                        Log.d("last date",c.getString(1));

                } catch (ParseException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                }
                try {
                        Future_date=(Date) formatter.parse(c.getString(2));
                        Log.d("future date",c.getString(2));
                } catch (ParseException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                }
                db.close();*/

        String s=today.toString();
        //to = (Date) formatter.parse(s);                
        //Last_date = (Date) formatter.parse(s);
                Calendar cal=Calendar.getInstance();
                try {
                        cal.setTime(formatter.parse(s));
                } catch (ParseException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                }
                //cal.setTime(today);
 catch (java.text.ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

                new File("/sdcard/journal").mkdirs();
/*cal.add( Calendar.DATE,240);
Log("60",cal.getTime());
long diff = daysBetween(Future_date,cal.getTime());
cal.add(Calendar.DATE,-240);
cal.setTime(Future_date);*/
                for(int i=-1;i<=180;i++)
                {
                       
                        String converted=formatter.format(cal.getTime());
                    Log.d("date",converted);
        File myFile = new File("/sdcard/journal/"+converted+".txt");
                if(!myFile.exists())
                {
                        try {
                                myFile.createNewFile();
                        } catch (IOException e) {
                                // TODO Auto-generated catch block
                                e.printStackTrace();
                        }
                }
                cal.add( Calendar.DATE,1);
                }
                Date to= new Date();
                    String s1=to.toString();
                    //to = (Date) formatter.parse(s);                
                    //Last_date = (Date) formatter.parse(s);
                            Calendar cal1=Calendar.getInstance();
                            try {
                                    cal1.setTime(formatter.parse(s1));
                            } catch (ParseException e1) {
                                    // TODO Auto-generated catch block
                                    e1.printStackTrace();
                            } catch (java.text.ParseException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
                            for(int j=0;j<=60;j++)
                            {
                            	cal1.add( Calendar.DATE,-1);
                            	String converted=formatter.format(cal1.getTime());
                            	File myFile = new File("/sdcard/journal/"+converted+".txt");
                            	 if (myFile.exists()) {
     				           long fileSize = myFile.length();
     					 if (fileSize==0)
     					 {
     						  myFile.delete();
     					 }
     						 myFile.setReadable(true);
     					 }
                            }
                    /*Date to = new Date();
                    long diff1 = daysBetween(Last_date,to);
                    //cal.setTime(Last_date);
                    for(int i=-1;i<=diff1;i++)
                    {
                    	cal.add( Calendar.DATE,1);
                    	String converted=formatter.format(cal.getTime());
                    	File myFile = new File("/sdcard/journal/"+converted+".txt");
                    	 if (myFile.exists()) {
				           long fileSize = myFile.length();
					 if (fileSize==0)
					 {
						  myFile.delete();
					 }
						 myFile.setReadable(true);
					 }
                    	 
                    }*/
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_display_menu, menu);
        return true;
    }

    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                NavUtils.navigateUpFromSameTask(this);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
    public void onClick (View v)
    {
    // 	Intent intent=getIntent();
    	if(v==journalid)
    	{
    		new File("/sdcard/journal").mkdirs();
    		File myFile = new File("/sdcard/journal/"+date_month_year+".txt");
			if(!myFile.exists())
			{
				try {
					myFile.createNewFile();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
    		FileInputStream fIn = null;
			try {
				fIn = new FileInputStream(myFile);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			BufferedReader myReader = new BufferedReader(new InputStreamReader(fIn));
			String aDataRow = "";
			String aBuffer = "";
			try {
				while ((aDataRow = myReader.readLine()) != null) {
					aBuffer += aDataRow + "\n";
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	//	setTitle(read);
    		//Database db= new Database(this);
    		//db.open();
    		//Cursor c=db.getdata(date_month_year);
    		//db.close();
    	/*	Database db= new Database(DisplayMenu.this);
    		db.open();
    		Cursor c=db.getdata(date_month_year);
    		db.close();*/
    		if(Integer.parseInt(read)==1)
    		{
    			
        		//if(Integer.parseInt(read)==1)
        		
    			
    			Intent intent= new Intent(this,Reader.class);
    			intent.putExtra(date,date_month_year);
    			/*if(c!=null)
    				 intent.putExtra(text,c.getString(1));
    			else
    				intent.putExtra(text,"noEntry");*/
    			intent.putExtra(text,aBuffer);
    			startActivity(intent);
        		
    		}
    		else
    		{
    			
    			Intent intent= new Intent(this, Writer.class);
    			intent.putExtra(date,date_month_year);
    			/*if(c!=null)
   				 	intent.putExtra(text,c.getString(1));
    			else
    				intent.putExtra(text,"");*/
    			intent.putExtra(text, aBuffer);
    			startActivity(intent);
    		}
    	}
    	if(v==videoid)
    	{
    		Intent intent= new Intent(this,Videos.class);
    		intent.putExtra(date, date_month_year);
    		startActivity(intent);
    	}
    	if(v==photoid)
    	{
    		Intent intent = new Intent(this, Photos.class);
    		intent.putExtra(date,date_month_year);
    		startActivity(intent);
    	}
    }
    public void onDestroy()
	{
		super.onDestroy();
	}
}

