package com.examples;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import android.support.v4.app.NavUtils;

public class Reader extends Activity {
	public String date_month_year;
	public String entry;
	private TextView tv;
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	Intent intent=getIntent();
    	date_month_year = intent.getStringExtra(DisplayMenu.date);
    	entry = intent.getStringExtra(DisplayMenu.text);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reader);
        //setTitle("Read Journal of "+date_month_year);
        setTitle("Daily Journal                                 "+date_month_year);
        tv = (TextView) findViewById(R.id.displaymessage);
       //tv.setTextSize(10);
       tv.setText(entry);
        
        
 //       getActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_reader, menu);
        return true;
    }

    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                NavUtils.navigateUpFromSameTask(this);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

}
