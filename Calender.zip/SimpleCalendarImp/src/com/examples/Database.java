package com.examples;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class Database {
	public static final String KEY_ID = "id";
	public static final String KEY_LAST = "l_date";
	public static final String KEY_FUTURE = "f_date";

	private static final String DATABASE_NAME = "mydb";
	private static final String DATABASE_TABLE = "J_table";
	private static final int DATABASE_VERSION = 1;
	
	private static final String DATABASE_CREATE = "create table J_table (id INTERGER PRIMARY KEY," +
			"l_date text,"+"f_date text, UNIQUE(l_date,f_date));";
	private final Context context;
	private DbHelper DBHelper;
	private SQLiteDatabase db;
	
	/*	private DbHelper ourHelper;
	private final Context ourContext;
	private SQLiteDatabase ourDatabase;*/
	public Database(Context ctx)
	{
		this.context=ctx;
	//	DBHelper = new DbHelper(context);
	}

	private class DbHelper extends SQLiteOpenHelper {

		public DbHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
			// TODO Auto-generated constructor stub
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub

			db.execSQL(DATABASE_CREATE);
		
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

			// TODO Auto-generated method stub
			db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
			onCreate(db);
		}

	}

/*	public Database(Context c) {
		ourContext = c;*/
	//}
	
	public Database open() throws SQLException{
		//ourHelper = new DbHelper(ourContext);
		DBHelper= new DbHelper(context);
		db = DBHelper.getWritableDatabase();
		return this;

	}

	public void close() {
		DBHelper.close();
	}

	public long createEntry(String date, String text) {
		// TODO Auto-generated method stub
		ContentValues cv = new ContentValues();
		cv.put(KEY_LAST, date);
		cv.put(KEY_FUTURE, text);
		return db.insert(DATABASE_TABLE, null, cv);
	}
	public Cursor getdata()
	{
		Cursor mCursor=
				db.query(DATABASE_TABLE, new String[] {
						KEY_ID,
						KEY_LAST,
						KEY_FUTURE
				},
				 null,null,null,null,null);
		
		return mCursor;
		}
	public boolean updateText(int id,String date,String text)
	{
		ContentValues args=new ContentValues();
		args.put(KEY_LAST, date);
		args.put(KEY_FUTURE,text);
		return db.update(DATABASE_TABLE, args, KEY_ID+"=\""+id+"\"", null)>0;
	}
	}
